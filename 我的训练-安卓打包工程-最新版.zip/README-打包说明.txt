我的训练 Android APK 封装工程

入口：app/src/main/assets/index.html
包名：com.ppp.mytraining
应用名：我的训练
最低 Android：6.0（API 23）

本工程是离线 WebView 封装：HTML/CSS/JS 全部随 APK 内置，不依赖网络才能打开。
已开启 JavaScript、DOM Storage、IndexedDB/File Access，并支持 HTML <input type=file> 选择 ZIP/JSON/CSV/GIF 等本地文件。

推荐方式：上传整个工程到 GitHub，Actions 会自动生成 debug APK，下载 app-debug.apk 后直接在安卓手机安装。

本地方式：Android Studio 打开本目录后运行 Gradle assembleDebug。
